=== Plugin Name ===
Contributors: victorjchamorro
Donate link:
Tags: email, forms, calls
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Word Press plugin to create a bar/layer with a simple form to indicate the contact data to call: name, email and telephone

== Description ==

Simple WordPress plugin to create a bar/layer with a simple form to indicate the contact data to call: name, email and telephone.

== Installation ==

1. Upload `we-will-call-you` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Configure the plugin in the > 'Settings' > 'We'll Call You'

== Changelog ==

= 1.0 =
* First version

== Screenshots ==

1. Layer form contact (shown)
2. Layer form contact (hidden)